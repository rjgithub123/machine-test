<?php $__env->startSection('content'); ?>
<div class="container-fluid" id="container-wrapper">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">

    </div>
    <?php if(Session::has('success')): ?>
    <div class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo e(Session::get('success')); ?>

    </div>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
    <div class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo e(Session::get('error')); ?>

    </div>
    <?php endif; ?>
    <div class="page-heading">

    </div>
    <div class="page-content">
<div class="card">
    <div class="card-body">
        <h1>
            Welcome!
        </h1>
    </div>
</div>
</div>
<!--Row-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\job\machinetask\resources\views/home.blade.php ENDPATH**/ ?>