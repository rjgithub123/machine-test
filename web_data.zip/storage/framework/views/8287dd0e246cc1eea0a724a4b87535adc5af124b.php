<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Add Sub Categories</h3>
    </div>
</div>
<form method="POST" action="<?php echo e(Route('sub_categories.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="col-md-6">
        <div class="form-group">
            <label> Category <span style="color:red;"> * </span></label>
            <select class="form-control" name="category_id">
                <option value="">-SELECT-</option>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->category_id); ?>"><?php echo e($value->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('category_id')): ?>
            <span class="help-block">
                <strong class="text-danger"><?php echo e($errors->first('category_id')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label> Title <span style="color:red;"> * </span></label>
            <input type="text" class="form-control" name="title" placeholder="Enter Title" id="title" value="<?php echo e(old('title')); ?>" required>
            <?php if($errors->has('title')): ?>
            <span class="help-block">
                <strong class="text-danger"><?php echo e($errors->first('title')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label> Content <span style="color:red;"> * </span></label>
            <textarea class="form-control" name="content" placeholder="Enter  Content" id="content"><?php echo e(old('name')); ?></textarea>
            <?php if($errors->has('content')): ?>
            <span class="help-block">
                <strong class="text-danger"><?php echo e($errors->first('content')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <input type="submit" class="btn-primary" name="submit" value="Submit">
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\job\machinetask\resources\views/sub_categories/sub_categories_add.blade.php ENDPATH**/ ?>