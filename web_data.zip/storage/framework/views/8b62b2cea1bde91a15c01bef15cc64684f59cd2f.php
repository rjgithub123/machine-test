<?php $__env->startSection('content'); ?>
<div class="box">
<div class="box-header">
<h3 class="box-title">Update Categories</h3>
</div></div>
<form method="POST" action="<?php echo e(Route('categories.update', $id)); ?>">
<?php echo e(csrf_field()); ?>

<?php echo e(method_field('PUT')); ?>



<div class="col-md-6">
   <div class="form-group">
       <label> Title <span style="color:red;"> * </span></label>
       <input type="text" class="form-control" name="title" value="<?php echo e($categories->title); ?>" placeholder="title" id="title" required>
       <?php if($errors->has('title')): ?> 
       <span class="help-block">
           <strong class="text-danger"><?php echo e($errors->first('title')); ?></strong>
       </span>
       <?php endif; ?>
   </div>
</div>
<div class="col-md-6">
   <div class="form-group">
       <label> Content <span style="color:red;"> * </span></label>
       <textarea  class="form-control" name="content" placeholder=" Enter  Content" id="content" required><?php echo e($categories->content); ?></textarea>     <?php if($errors->has('content')): ?> 
       <span class="help-block">
           <strong class="text-danger"><?php echo e($errors->first('content')); ?></strong>
       </span>
       <?php endif; ?>
   </div>
</div>
<div class="col-md-6">
   <div class="form-group">
<input type="submit" class="btn-primary" name="submit" value="Submit"> 
</div></div></form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\job\machinetask\resources\views/categories/categories_edit.blade.php ENDPATH**/ ?>