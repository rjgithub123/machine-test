<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('Reubro', 'Machine Task')); ?></title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?> ">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.svg')); ?>" type="image/x-icon">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js">
    </script>
</head>

<body>
    <div id="app">
        <div id="sidebar" class="active">
            <div class="sidebar-wrapper active">
                <div class="sidebar-header">

                </div>
                <div class="sidebar-menu">
                    <ul class="menu">
                        <li class="sidebar-item active ">
                            <a href="<?php echo e(url('/')); ?>" class='sidebar-link'>
                                <i class="bi bi-grid-fill"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>

                        <li class="sidebar-item">
                            <a href="<?php echo e(url('categories')); ?>" class='sidebar-link'>
                                <i class="bi bi-grid-fill"></i>
                                <span>Category</span>
                            </a>
                        </li>

                        <li class="sidebar-item">
                            <a href="<?php echo e(url('sub_categories')); ?>" class='sidebar-link'>
                                <i class="bi bi-grid-fill"></i>
                                <span>Sub Category</span>
                            </a>
                        </li>

                        <li class="sidebar-item">
                            <a href="<?php echo e(url('product')); ?>" class='sidebar-link'>
                                <i class="bi bi-grid-fill"></i>
                                <span>Products</span>
                            </a>
                        </li>
                    </ul>
                </div>
                <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
            </div>
        </div>
        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
  
    <script src="<?php echo e(asset('assets/js/sweetalert.min.js')); ?>"></script>
    <script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('assets/js/jquery-ui.js')); ?>"></script>

</body>

</html><?php /**PATH E:\job\machinetask\resources\views/layouts/app.blade.php ENDPATH**/ ?>