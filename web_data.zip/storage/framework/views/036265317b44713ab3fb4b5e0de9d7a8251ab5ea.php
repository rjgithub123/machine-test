<?php $__env->startSection('content'); ?>
<?php if(Session::has('success')): ?>
                    <div class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                    <div class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <?php echo e(Session::get('error')); ?>

                    </div>
                    <?php endif; ?>
<div class="col-xs-12">
<div class="box">
<div class="box-header">
<h3 class="box-title">Categories List</h3>
<div class="box-tools">
<div class="input-group input-group-sm pull-right">
<a href="<?php echo e(Route('categories.create')); ?>" class="btn btn-primary">Add New</a>
</div>
</div>
</div>
<div class="box-body table-responsive no-padding">
<table class="table table-hover">
<tr>
<th>#</th>
<th>Slug</th>
<th>Title</th>
<th>Content</th>
<th>Action</th>
</tr>
<?php if($categories->count() > 0): ?>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e((($categories->currentPage() - 1 ) * $categories->perPage() ) + $loop->iteration); ?></td>
<td><?php echo e(isset($value->slug) ? $value->slug : '-'); ?></td>
<td><?php echo e(isset($value->title) ? $value->title : '-'); ?></td>
<td><?php echo e(isset($value->content) ? $value->content : '-'); ?></td>

<td>
<span>
<a href="<?php echo e(Route('categories.edit' ,encrypt($value->category_id) )); ?>">
<i class="fa fa-edit">Edit</i>
</a>
</span>
<span>
<a title="Delete" onclick=deleteCategories(<?php echo e($value->category_id); ?>) style="cursor:pointer;">
<i class="fa fa-remove">Delete</i>
</a>
</span>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<tr>
<td colspan="6" class="text-bold text-danger text-center">
No Data Found
</td>
</tr>
<?php endif; ?>
</table>
</div>
<?php echo e($categories->render()); ?>

</div>
</div>


<script>
let token = "<?php echo e(csrf_token()); ?>";
function deleteCategories(id)
{
swal({
title: "Are you sure?",
text: "Once deleted, you will not be able to recover this !",
icon: "warning",
buttons: true,
dangerMode: true,
})
.then((willDelete) => {
if (willDelete) {
$.ajax({type: "DELETE",
url: '/categories/destroy',
async:true,
data: {
'_token'     : token,
'category_id'  : id},
success: function(response) {
console.log(response);
if(response) {
if(response == "Success") {
swal("Success!", "Categories deleted successfully.", "success", {
button: "Ok",
}).then(function() {
window.location.reload();
});
}
if(response == "Error") {
swal("Error!", "Error deleting Categories!.", "error", {
button: "Ok",
})
}
} else {
console.log("Error");
}
}
});
} else {
swal("Cancelled!", "You cancelled the operation.", "error", {
button: "Ok",
})
}
});
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\job\machinetask\resources\views/categories/categories_list.blade.php ENDPATH**/ ?>