<?php $__env->startSection('content'); ?>
<?php if(Session::has('success')): ?>
                    <div class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                    <div class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <?php echo e(Session::get('error')); ?>

                    </div>
                    <?php endif; ?>
<div class="col-xs-12">
<div class="box">
<div class="box-header">
<h3 class="box-title">Sub Categories List</h3>
<div class="box-tools">
<div class="input-group input-group-sm pull-right">
<a href="<?php echo e(Route('sub_categories.create')); ?>" class="btn btn-primary">Add New</a>
</div>
</div>
</div>
<div class="box-body table-responsive no-padding">
<table class="table table-hover">
<tr>
<th>#</th>
<th>Slug</th>
<th>Title</th>
<th>Content</th>

</tr>
<?php if($subcategories->count() > 0): ?>
<?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e((($subcategories->currentPage() - 1 ) * $subcategories->perPage() ) + $loop->iteration); ?></td>
<td><?php echo e(isset($value->slug) ? $value->slug : '-'); ?></td>
<td><?php echo e(isset($value->title) ? $value->title : '-'); ?></td>
<td><?php echo e(isset($value->content) ? $value->content : '-'); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<tr>
<td colspan="6" class="text-bold text-danger text-center">
No Data Found
</td>
</tr>
<?php endif; ?>
</table>
</div>
<?php echo e($subcategories->render()); ?>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\job\machinetask\resources\views/sub_categories/sub_categories_list.blade.php ENDPATH**/ ?>