<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(Route('product.store')); ?>">
<?php echo csrf_field(); ?>
<div class="col-md-6">
   <div class="form-group">
       <label> Category<span style="color:red;"> * </span></label>
       <select class="form-control" name="category_id" id="category_id">
                <option value="">-SELECT-</option>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value->category_id); ?>"><?php echo e($value->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
       <?php if($errors->has('category_id')): ?> 
       <span class="help-block">
           <strong class="text-danger"><?php echo e($errors->first('category_id')); ?></strong>
       </span>
       <?php endif; ?>
   </div>
</div>

<div class="col-md-6">
   <div class="form-group">
       <label>SubCategory</label>
       <select class="form-control" name="sub_category_id" id="sub_category_id" >
                <option value="">-SELECT-</option>
            </select>
       <?php if($errors->has('sub_category_id')): ?> 
       <span class="help-block">
           <strong class="text-danger"><?php echo e($errors->first('sub_category_id')); ?></strong>
       </span>
       <?php endif; ?>
   </div>
</div>

<div class="col-md-6">
   <div class="form-group">
       <label> Title <span style="color:red;"> * </span></label>
       <input type="text" class="form-control" name="title" placeholder="Enter Title" id="title" value="<?php echo e(old('title')); ?>" required>
       <?php if($errors->has('title')): ?> 
       <span class="help-block">
           <strong class="text-danger"><?php echo e($errors->first('title')); ?></strong>
       </span>
       <?php endif; ?>
   </div>
</div>

<div class="col-md-6">
   <div class="form-group">
       <label> Content </label>
       <textarea  class="form-control" name="content" placeholder="Enter  Content" id="content"><?php echo e(old('name')); ?></textarea>
       <?php if($errors->has('content')): ?> 
       <span class="help-block">
           <strong class="text-danger"><?php echo e($errors->first('content')); ?></strong>
       </span>
       <?php endif; ?>
   </div>
</div>
<div class="col-md-6">
   <div class="form-group">
<input type="submit" class="btn-primary" name="submit" value="Submit"> 
</div></div></form>
<!-- <script>
   function category_change()
   {
       var category_id=document.getElementById('category_id').value;
        // Creating Our XMLHttpRequest object 
        var xhr = new XMLHttpRequest();
        // Making our connection  
        var url = '/get_subcategory/'+category_id;
        xhr.open("GET", url, true);
  
        // function execute after request is successful 
        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
              //  console.log(this.responseText);
              var arr=this.responseText;
              alert(arr.length);
                alert(this.responseText)
            }
        }
        // Sending our request 
        xhr.send();
    }
</script> -->
<script>
let token = "<?php echo e(csrf_token()); ?>";
$('#category_id').on('change', function (e) {
        $.ajax({
            type: "get",
            url: "<?php echo e(url('get_subcategory')); ?>",
            async: true,
            data: {
                category_id: $('#category_id').val()
            },
            success: function (response) {
                $.each(response,function(key, value)
                {
                    $("#sub_category_id").append('<option value=' + value['category_id'] + '>' + value['title'] + '</option>');
                });
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\job\machinetask\resources\views/product/product_add.blade.php ENDPATH**/ ?>